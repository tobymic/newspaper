 <?php

function tobi_theme_support(){
    //Adds dynamic title tag
    add_theme_support('title-tag');
}

add_action('after_setup_theme','tobi_theme_support');


function tobi_menus(){

    $locations = array(
        'topbar' => "Desktop Top Bar Menu",
        'primary' => "Desktop Primary Menu",
        'footer' => "Footer Menu Items"
    );

    register_nav_menus($locations);
}

add_action('init','tobi_menus');



function load_stylesheets()
{

wp_register_style('slick', get_template_directory_uri() . '/lib/slick/slick.css', array(), 1, 'all');
wp_enqueue_style('slick');

wp_register_style('slicktheme', get_template_directory_uri(). '/lib/slick/slick-theme.css', array(), 1, 'all');
wp_enqueue_style('slicktheme');       
        
wp_register_style('css', get_template_directory_uri(). '/css/style.css', array(), 1, 'all');
wp_enqueue_style('css');       
        

}

add_action('wp_enqueue_scripts', 'load_stylesheets');


//Load scripts 

function addjx()
{

    wp_register_script('easing', get_template_directory_uri(). '/lib/easing/easing.min.js',  array() , 1, 1, 1);
    wp_enqueue_script('easing');

    wp_register_script('easing', get_template_directory_uri(). '/lib/easing/easing.js',  array() , 1, 1, 1);
    wp_enqueue_script('easing');

    wp_register_script('slick', get_template_directory_uri(). '/lib/slick/slick.min.js', array() , 1, 1, 1);
    wp_enqueue_script('slick');

    wp_register_script('slick', get_template_directory_uri(). '/lib/slick/slick.min.js', array() , 1, 1, 1);
    wp_enqueue_script('slick');

    wp_register_script('main', get_template_directory_uri(). '/js/main.js', array() , 1, 1, 1);
    wp_enqueue_script('main');


}




?>